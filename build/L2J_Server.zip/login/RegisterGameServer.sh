#!/bin/sh
java -Djava.util.logging.config.file=console.cfg -cp ./../libs/*:l2jlogin.jar com.l2jserver.tools.gsregistering.GameServerRegister -c